# Reigh on Astrid — self-contained project pack

## What this is

This pack describes the planned rebuild of Reigh from a Supabase/Postgres-backed, cloud-capable GPU-worker product into a fresh-start, local, single-user creative application. The finished application has one structured authority—Astrid's SQLite kernel—reached through one loopback HTTP bridge. It runs generation locally through Wan2GP or VibeComfy, treats the shot editor as a view of the single timeline document, and renders managed MP4s locally through Astrid Remotion. It deliberately carries no login, billing, sharing, remote-worker, cloud-provider, sync, or legacy-data-import system.

The pack is a curated build handoff. It contains the product intent, binding decisions, end state, implementation contract, delivery phases, task model, and the ten unresolved engineering questions most likely to change the outcome. It is designed to stand alone; source labels such as “doc 27” provide provenance to the larger design dossier but are not required reading.

## Authority

If wording inside this pack appears to conflict, use this order:

1. `03-constitution.md` — ratified owner decisions and defaults.
2. `04-build-spec.md` — the surviving working build contract.
3. `05-roadmap.md` — sequencing and phase gates.
4. The other files — explanation, end-state narrative, task-model detail, and open design questions.

This mirrors the dossier's own authority order: decisions in source docs 15, 24, 25, and `grok/second-opinion-decisions.md`; then build contract doc 27; then journey doc 22. Historical designs are evidence only where the current contract retains them. (Source: dossier `README.md`; docs 22 and 27.)

## File map

- `01-overview.md` — what is changing, why, how the design converged, and what “done” means.
- `02-end-state.md` — ten concrete end-state statements, their consequences, and a typical day in the product.
- `03-constitution.md` — all binding product, storage, UX, execution, and task-model decisions in one place.
- `04-build-spec.md` — the database, bridge, lease/fence, completion, worker, and polling contracts builders must preserve.
- `05-roadmap.md` — Phase A vertical slice, Phase B capability expansion, and Phase C cutover/release.
- `06-task-model.md` — capability identity, executor binding, custom workflows, orchestration, and Wan2GP updates.
- `07-questions.md` — ten high-leverage questions still worth answering before the architecture hardens.

## The governing idea

One authority, one bridge, one document, and local execution are not aspirations; they are simplification constraints. The fresh start is equally deliberate: the work is to build the coherent local product, not to preserve the architecture or data journey of the hosted one. (Sources: docs 15, 24, 25, and 27.)
