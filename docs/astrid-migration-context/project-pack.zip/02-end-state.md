# Reigh on Astrid: the finished product

## End-state picture

The finished Reigh is a trusted, single-user local application. The browser editor and one supervised worker communicate with `astrid serve` over loopback HTTP. Astrid's SQLite file is the only structured authority; its SHA-256 managed media tree is authoritative for bytes; and all mutations pass through one writer queue. The worker dispatches locally to Wan2GP, VibeComfy, or Astrid/Remotion and never opens SQLite. (Sources: docs 22 §§2–3; 27 §§1–2, 6.)

```text
Reigh browser/editor
  │ family admission, reads, timeline CAS, managed media
  ▼
astrid serve on loopback
  ├── one writer queue → one Astrid SQLite file
  └── SHA-256 managed media tree
  ▲
  │ claim, heartbeat, multipart complete/fail
one same-host worker
  ├── Wan2GP
  ├── VibeComfy
  └── Astrid/Remotion render
```

The following ten statements are the product constitution in concrete form. Each includes the consequence engineers and product designers must preserve.

## Ten binding end-state statements

### 1. No login: this is a local tool, not a cloud tenancy system

There are no accounts, JWTs, row-level security policies, personal access tokens, credits, billing, or sharing permissions in the supported runtime. The trust boundary is the loopback-bound bridge with strict CORS, request validation, path containment, receipts, CAS, and attempt fences. Cloud-era identity machinery is removed, not rebuilt in SQLite. (Sources: docs 15 Q5 and “Binding decisions”; 25 statement 1; 27 §1.)

### 2. The shot editor is a view mode of the video editor

Shot-focused work can have a purpose-built interface, but it uses the same timeline document, save operation, CAS version, and undo history as ordinary timeline editing. It cannot create a second editor state or synchronization boundary. (Sources: docs 24 Q1; 25 statement 2; 22 §6.)

### 3. The timeline document is the shot database

Shot groups, generation pools, timing, ordering, clip placement, and boundary overrides live in `timelines.document_json` and its `asset_registry_json`, stored in SQLite and versioned by whole-document CAS. There are no relational placement rows to normalize, mirror, reorder, or reconcile. Existing Astrid `shots`/`shot_items` tables remain dormant rather than becoming a mirror. (Sources: docs 09 §§4–5; 24 Q1; 25 statement 3; 27 §§1–2.)

### 4. Generations are rows; placement is document structure

`generations` and `generation_variants` remain relational so gallery, lineage, starring, primary-variant, and provenance queries have stable identities and bounded reads. Group membership and clip position remain only in the timeline document. Completion may create a generation and its initial primary variant atomically, but it does not create a competing placement authority. (Sources: docs 24 Q1; 25 statement 4; 27 §§2.2–2.3, 5.)

### 5. One SQLite file is the only database

Supabase, a placement database, a worker-owned store, and JSON sidecar authorities do not appear on a supported read or write path. SQLite owns structured truth; the managed media tree stores verified bytes. Browser and worker reach state only through the bridge, and every mutation enters Astrid's single writer queue. (Sources: docs 22 §§2–3; 25 statement 5; 27 §§1–2.)

### 6. Polling is the realtime model

The browser polls task state about every two seconds while work is queued or running, every ten seconds when idle, and the timeline every 30 seconds as a safety refresh. Admission, cancellation, and observed completion cause immediate query invalidation. SSE and WebSockets are deferred: receipts, live lease fences, atomic writes, and timeline CAS establish correctness; polling controls only how soon the UI observes it. (Sources: docs 15 Q7; 24 Q6; 25 statement 6; 27 §7.)

### 7. The user's machine is the data center

Every supported generation, orchestration step, and render runs locally. There is no fallback to Fal, Wavespeed, RunPod, or another outbound provider. At boot, a secret-free availability manifest checks the pinned Wan build, local model hashes, ComfyUI/VibeComfy nodes, ready-template digests, Remotion/Node/ffmpeg, and disk; unavailable capabilities stay hidden or return actionable setup guidance. (Sources: docs 24 Q3 and remaining consideration 1; 25 statement 7; 27 §§3, 6.)

### 8. Fresh start means old Supabase data is absent by decision

The supported product contains no production importer, legacy exporter, replay/archive layer, compatibility path, rollback authority, or deferred historical-data phase. Earlier migration research remains forensic evidence, but implementation starts from an empty local authority. This does not prohibit normal local backup and restore. (Sources: dossier README; docs 22 §§1, 3, 6–7; 25 statement 8; 27 §1.)

### 9. Video export is an Astrid task

The browser admits `render_export`; the bridge resolves it to Astrid's `rendering.timeline_visualize`; local Remotion produces an MP4; atomic completion records it as managed media; and the browser plays it through the common Range/ETag content route. Progress, cancellation, retry, provenance, storage, and playback use the same task/media contracts as generation output. There is no separate browser-only final-render pipeline. (Sources: docs 24 Q4; 25 statement 9; 27 §§3.1, 4.1, 5.)

### 10. A large gallery is a delivery problem, not a placement-schema mandate

A thousand generations justify bounded and paged generation reads, measured document-size limits, and—when evidence supports it—local thumbnail tasks or additional read projections. They do not justify reconstructing shot placement as relational tables. Scale work must optimize delivery without inventing a second source of truth. (Sources: docs 24 remaining considerations 2–3; 25 statement 10; 27 §§4.1, 7.)

## [INFERENCE] A typical day in the finished product

This walkthrough synthesizes the binding behavior above; it is not an additional feature commitment.

1. **Launch locally.** The launcher starts `astrid serve` and the one worker. A boot probe checks models, workflow templates, Comfy nodes, Remotion/Node/ffmpeg, and free disk. Reigh opens without a login screen because the local project is already the user's authority. Missing prerequisites produce setup actions instead of provider credentials. (Sources: docs 22 §6; 27 §6.)
2. **Open or create a project.** The browser discovers projects and timelines through the loopback bridge and loads the timeline document plus asset registry from SQLite. A 30-second safety poll can observe other local writes; edits save with an expected version, and a genuine CAS conflict is surfaced rather than overwritten. (Sources: doc 09 §§3–5; doc 27 §§4, 7.)
3. **Work in the shot view.** The user switches the editor into its focused shot mode, groups candidate generations, adjusts pools, timing, ordering, and boundaries, then returns to the wider timeline. Nothing is copied between editors: both modes edited the same document and share undo/save history. Duplicating a group is a deep copy of its structure and media references and enqueues/copies generated final-video assets, with lineage back to the source. (Sources: doc 24 Q1–Q2; doc 25 statements 2–4.)
4. **Generate locally.** An editor action submits `{family, input}` with an idempotency key. The bridge resolves the family to one available flat capability and one binding. The worker claims a leased attempt, downloads managed inputs, runs Wan2GP or VibeComfy, and heartbeats progress. The UI polls approximately every two seconds. (Sources: `grok/second-opinion-decisions.md` D1/D3; doc 27 §§3–4, 6–7.)
5. **Observe one atomic result.** The worker sends output bytes and a manifest in one multipart completion request. The server hashes and validates the bytes, then commits task success, attempt success, output/media rows, generation, initial primary variant, and required asset-registry visibility in one transaction. A crash, stale fence, corrupt byte stream, or disk failure yields no partial authoritative generation. A lost response can be replayed using the same completion key. (Sources: docs 22 §4; 27 §§4.4, 5, 8.)
6. **Browse and place.** The new item appears in a bounded gallery query. The user can star it, inspect variants and provenance, or place it into the timeline; gallery identity lives in rows while placement changes only the timeline document. Imported material and outputs are always copied into managed storage. (Sources: doc 24 Q1/Q5; doc 27 §§2, 4.1, 7.)
7. **Render and review.** The user requests a final video. Render enters the same task system, runs through local Astrid/Remotion, reports progress through polling, and commits a managed MP4. The browser streams that file from the bridge with Range/ETag support for review. (Sources: doc 24 Q4; doc 27 §§4–5.)
8. **Close with local ownership intact.** SQLite and the managed media tree contain the authoritative project; backup/restore protects them. No project state, task, generation, or render was sent to a cloud service. (Sources: docs 22 §6; 25 statements 5 and 7.)

## What explicitly does not exist

- **No login or account system:** no auth gate, JWT, RLS, PAT, tenancy, public/anonymous sharing, or multi-user permissions.
- **No credits or commerce:** no credit ledger, billing, Stripe, referrals, or usage charging.
- **No cloud execution:** no Fal, Wavespeed, RunPod, remote workers, provider router, autoscaler, fleet registry, or cloud fallback.
- **No cloud sync:** no cross-device/server synchronization authority and no hosted realtime channel; local browser freshness comes from polling the loopback bridge.
- **No legacy-data importer:** no supported Supabase importer, exporter, replay, historical compatibility, archive, or rollback path. “Export video” remains the local Astrid render task described above.
- **No second editor or placement store:** no shot-specific persistence tables, mirrored shot state, or second undo/save history.
- **No runtime extension maze:** no capability aliases, wildcard admissions, multiple active bindings, binding picker, runtime Python plugins, promotion service, or dead legacy task types.
- **No worker database access:** no direct SQLite or Supabase fallback, signed cloud upload, worker registry, executor heartbeat endpoint, or queue-summary control plane.
- **No push prerequisite:** no SSE or WebSocket requirement for v1.
- **No link-in-place media:** files and outputs are copied into the managed media tree; external paths are not an authority. (Sources: docs 22 §§3, 7; 24; 25; `grok/second-opinion-decisions.md`; doc 27 §§1, 3–7.)

## End-state acceptance test

From an empty local authority, a clean installation can discover or create a project, edit one CAS-versioned timeline document in both general and shot-focused views, run every advertised capability locally, recover leased work safely, cancel tasks, browse generations and variants, manage copied media, render a timeline to a managed MP4, play it in the browser, and back up and restore the project. The browser talks only to `astrid serve`; no supported startup or workflow needs a Supabase/provider credential, endpoint, data export, rollback window, remote worker, or second structured store. (Sources: doc 22 §6 exit criteria; doc 27 §§8–9.)
