# Reigh on Astrid: working build contract

This is the implementation contract for rebuilding Reigh as a local, single-user product on Astrid. If an older migration design conflicts with this file, the ratified constitution wins first and source document 27 wins second. Source documents 09 and 27 define the frozen bridge and the surviving build surface; documents 15, 24, 25, and `grok/second-opinion-decisions.md` supply the binding product decisions.

## 1. Product and authority boundary

The finished product has one structured authority: one Astrid SQLite database. Astrid's SHA-256 managed media tree is the authority for bytes. The Reigh browser and one same-host worker communicate only with the loopback `astrid serve` HTTP listener; neither may open SQLite. Every mutation, including bridge requests, task settlement, and pack commands, passes through Astrid's existing single-writer queue.

V1 has no Supabase authority, importer, replay layer, rollback authority, auth or tenancy, billing, remote workers, autoscaling, outbound generation provider, runtime plugin loader, or second shot-placement store. Media is always copied into the managed tree. References, evidence, understanding, kernel ULIDs, hash-chained kernel events, the single-writer unit of work, backup/restore primitives, and the frozen timeline bridge remain intact.

Shot groups, generation pools, timing, order, and boundary overrides live only in the CAS-versioned timeline document. Generations and variants are relational records; placement is document structure. Existing `shots` and `shot_items` tables remain dormant and are not Reigh authority. There is no `shot_generation_items` table.

The `shots` pack advances to migration v2 with only:

- `generations`: text primary key; project with cascade delete; nullable task and base-generation links with `SET NULL`; nullable parent with cascade delete; non-negative child order; valid-JSON parameters defaulting to `{}`; boolean starred; soft-delete timestamp; created/updated timestamps; and self-reference checks.
- `generation_variants`: text primary key; generation with cascade delete; media with `ON DELETE RESTRICT`; optional type/name; valid-JSON parameters defaulting to `{}`; boolean primary/starred; viewed/created timestamps; unique `(generation_id, media_id)`; and a partial unique index allowing at most one primary variant per generation.
- The paging, project, lineage, task, and media lookup indexes specified by the source design.

There is no generation-specific event stream. When an output policy requests a gallery entry, `record_completion` creates its generation and initial primary variant inside task completion. Star/unstar, set-primary, variant metadata update, and soft-delete are small pack commands serialized by the same writer; they enforce the schema but add neither a second CAS protocol nor per-generation events. A second independent writer—not expected in v1—is the condition for reconsidering that choice.

## 2. Capability registry and admission

The frontend admits by `family`; the server resolves that request to a flat capability ID. Shipped IDs use `reigh.<normalized_task_type>`, except Astrid's render capability `rendering.timeline_visualize`. Every capability has exactly one code-declared local binding and is advertised only when its boot-time availability probe succeeds:

| Frontend family | Capability IDs | Binding |
|---|---|---|
| `image_generation` | `reigh.wan_2_2_t2i`, `reigh.qwen_image`, `reigh.qwen_image_style`, `reigh.qwen_image_2512`, `reigh.z_image_turbo` | WGP for Wan; VibeComfy for the others |
| `image_upscale` | `reigh.image_upscale` | VibeComfy |
| `individual_travel_segment` | `reigh.individual_travel_segment` | WGP |
| `join_clips` | `reigh.join_clips_orchestrator` | WGP |
| `video_enhance` | `reigh.video_enhance` | VibeComfy |
| `z_image_turbo_i2i` | `reigh.z_image_turbo_i2i` | VibeComfy |
| `magic_edit` | `reigh.qwen_image_edit` | VibeComfy |
| `masked_edit` | `reigh.image_inpaint`, `reigh.annotated_image_edit` | VibeComfy |
| `travel_between_images` | `reigh.travel_orchestrator`, `reigh.wan_2_2_i2v` | WGP |
| `crossfade_join` | `reigh.travel_stitch` | WGP |
| `edit_video_orchestrator` | `reigh.edit_video_orchestrator` | WGP |
| `character_animate` | `reigh.animate_character` | VibeComfy |
| `klein_edit` | `reigh.flux_klein_edit` | VibeComfy |
| render/export | `rendering.timeline_visualize` | Astrid Remotion |

Each registry entry contains only: capability ID, frontend family, input validator/resolver, output policy, its one executor binding, availability probe, and an optional ready-template path plus digest. It does not choose among bindings. Tasks pin only output-relevant provenance in `spec_json`: source family/type, definition version, workflow digest when applicable, and model hash. The process boot manifest—not every task—records the pinned Wan SHA, ComfyUI/node versions, runtime ABI facts, ready-template digests, Remotion/Node/ffmpeg, local model hashes, and disk preflight.

Shipped Comfy workflows are in-repository `ready_templates`. A user workflow is immutable workflow bytes, hashed at admission and pinned by digest. Its declarative YAML is limited to `{id, ports, workflow_path, digest, output_policy}`; it uses either `local.<slug>` or one generic `local.workflow.run`, both reaching the same generic VibeComfy handler. There is no runtime Python/plugin loading or promotion service; promotion is an in-repository, restart-visible change.

Dead legacy types are rejected, never aliased. This includes `edit_video_segment`, `edit_travel_flux`, `image_edit`, underscore `image_upscale`, `magic_edit`, and `single_image`. Kernel ULIDs are task identity everywhere; workers do not pre-generate UUID task IDs, and no logical-ID cache or alias table exists.

### Public admission and child admission

Public admission is project-scoped `{family, input, materialized_inputs?, priority?}` and requires `Idempotency-Key`. Browser callers may not request child-only families.

The only worker-child types are `reigh.join_clips_segment`, `reigh.join_final_stitch`, `reigh.travel_segment`, `reigh.travel_stitch`, and `reigh.join_clips_orchestrator`, and each is exposed only if its sole binding and prerequisites pass the boot probe. An internal child request carries a server-validated envelope with parent task ULID, parent attempt number, executor ID, lease ID, and current fence. The bridge admits it only when:

1. the parent is the caller's live, unexpired leased attempt;
2. the requested type is on the child-only allowlist;
3. the idempotency key is exactly `reigh.orch:v1:<parent>:<role>:<index>`;
4. hard dependencies point to kernel task ULIDs; and
5. the child inherits its parent's project and run context.

Orchestrator parents remain `running` and heartbeat while children execute, without occupying GPU capacity. Their fenced executor replays child admissions after a crash or lost acknowledgement, observes hard dependencies, and explicitly completes or fails the parent. Structural whole-graph runs are deferred.

## 3. Surviving HTTP contract

All routes live on the existing loopback bridge listener and retain its strict CORS, canonical JSON, receipt secrecy, project scoping, and error-envelope conventions.

### Frozen timeline and asset surface

- `GET /health`
- `GET /projects`
- `GET /projects/:slug/timelines`
- `GET /projects/:slug/timelines/:ref`
- `POST /projects/:slug/timelines/:ref/save`
- `GET|HEAD /projects/:slug/timelines/:ref/assets/:key`
- `OPTIONS`

Timeline save remains a whole-document compare-and-swap request: `{config, registry, expected_version}`. A stale version produces `409 timeline_version_conflict` and no mutation; a successful save atomically stores document and registry, appends `timeline.saved`, advances the stream head, and stores a hidden derived receipt. The save response never exposes receipt internals. Timeline asset reads retain verified path containment, Range, ETag, conditional response, and `HEAD` behavior. These frozen semantics are not renamed or replaced. (Source: doc 09 §§1, 4–7; doc 27 §4.)

### Task, queue, media, and generation surface

| Route | Contract |
|---|---|
| `POST /projects/:slug/tasks` | Public family admission, fenced internal child admission, or render admission. `Idempotency-Key` required. |
| `GET /projects/:slug/tasks` | Bounded task/progress/output reads for polling. |
| `GET /projects/:slug/tasks/:task_id` | One task/progress/output read. |
| `POST /projects/:slug/tasks/:task_id/cancel` | Common queued/running cancellation; no public idempotency key. |
| `POST /queue/claim` | Claim eligible work and create a leased `running` attempt; returns work or `204`. |
| `POST /tasks/:task_id/attempts/:attempt_no/heartbeat` | Extend the current lease and report bounded progress. |
| `POST /tasks/:task_id/attempts/:attempt_no/complete` | Multipart files plus fence and output manifest; server hashes and commits atomically. `Idempotency-Key` required. |
| `POST /tasks/:task_id/attempts/:attempt_no/fail` | Fenced, bounded failure; the server applies retry budget. `Idempotency-Key` required. |
| `GET|HEAD /projects/:slug/media/:media_id/content` | Verified managed bytes with Range and ETag. |
| `GET /projects/:slug/generations` | Bounded gallery page with primary-variant summary. |
| `GET /projects/:slug/generations/:generation_id` | Generation detail including variants. |

There is no separate start, output/staging, render, executor-heartbeat, queue-summary, or project-wide variants route. Render is submitted through task admission as family `render_export`, resolves to `rendering.timeline_visualize`, and uses common reads and cancellation.

**Claim.** `POST /queue/claim` accepts `{executor_id, capabilities, lease_seconds?}`. Success creates the next attempt directly in `running` and returns `attempt_id`, `attempt_no`, `lease_id`, `lease_expires_at`, current kernel fence/version, task spec, and resolved managed inputs. No work returns `204` and writes no receipt. Selection is globally deterministic by priority, availability, creation time, then task ULID. This global ordering replacing project iteration and old affinity/starvation fields is an `[INFERENCE]` carried by source doc 27; `max_task_wait_minutes` is not a contract field.

**Heartbeat.** The request carries the live lease/fence and optional bounded progress; its response carries the next fence. It writes neither event nor receipt. A small worker mutex serializes heartbeat against complete/fail. Once settlement begins, heartbeats stop and the terminal call uses the last returned fence.

**Complete.** One `multipart/form-data` request contains a JSON fence/manifest part and one or more raw files. The server streams each file to request-scoped quarantine, calculates SHA-256, checks declared size/type limits, and only then submits one writer callback. Quarantine paths, upload URLs, and staging transaction IDs never enter the wire contract. A failure before commit leaves no authoritative rows and permits cleanup. Replaying the same completion key returns the stored result; changing semantic input under that key returns `409 conflict`.

**Fail and cancel.** Fail carries the current lease/fence and bounded `{code, message, retryable}`. The server applies `max_attempts` and returns `requeued` or terminal `failed`. A running cancel is fenced; cancelling queued/blocked work creates no fictitious attempt; repeating cancel returns the current terminal state.

New build-facing errors have five categories: `invalid_body`, `not_found`, `conflict`, `capability_unavailable`, and `payload_too_large`. Detailed repository reasons stay in local logs. A `409 conflict` may reveal only the current attempt number, lease expiry, and fence when the owning executor needs them to stop or resynchronize. Frozen timeline errors remain unchanged. The child gate may return `child_admission_forbidden`; unknown, dead, or unavailable capabilities return `422 capability_unavailable` with local setup or unsupported guidance.

## 4. Atomic completion unit of work

Crash-safe completion is the central invariant. Bytes are prepared and hashed outside the writer lock. Exactly one callback then opens one `BEGIN IMMEDIATE` transaction and performs, in order:

1. completion receipt replay or mismatch check;
2. validation of the current live lease and fence;
3. staged-byte, digest, and size validation and managed-media materialization;
4. writes to `media`, `media_locations`, `media_relations`, and `task_outputs`;
5. task and attempt transition to succeeded with exactly one winning attempt;
6. when output policy requests it, generation and initial variant creation through `record_completion`;
7. only when needed for addressability, an internal evented asset-registry merge against the current timeline head—never an edit of shot groups, pools, timing, or boundaries;
8. completion receipt write; and
9. commit.

Any failure rolls back every authoritative row. Astrid publishes bytes to their SHA-256 managed location under its existing media discipline; poisoned, mismatched, missing, truncated, over-limit, or disk-failed bytes cannot yield a successful task or visible generation. Render uses the same transaction with `create_generation=false`, commits a primary `video/mp4` task output, and exposes it through the common media route.

## 5. Worker and polling model

One local worker runs beside `astrid serve`, supervised by the local launcher. It may internally dispatch WGP, VibeComfy, and Astrid rendering, but has one bridge client and one claim loop. That client implements only claim, heartbeat, complete, fail, task reads, fenced child admission, and media download. Admission/complete/fail may retry a transport loss with the same key; claim and heartbeat are always new operations and have no receipts.

There is no worker registry, executor heartbeat route, queue-summary gate, phantom-claim recovery, direct-database fallback, signed upload, provider handler, API-orchestrator process, or cloud-fleet process. Fal and Wavespeed handlers, secrets, routing, and retries are removed. Handlers formerly under an API run type move behind the worker's local VibeComfy binding.

The app polls task/progress reads every 2 seconds while anything is queued or running, every 10 seconds while idle, and the timeline every 30 seconds as a safety refresh. Admission, cancellation, and an observed terminal transition immediately invalidate task, gallery, and timeline queries. Timeline saves stay optimistic and CAS-protected; worker completion never makes a public full-document save. Gallery paging and document JSON size are measured using production-shaped fixtures before adding document paging or a variants-first route. Thumbnails are a later cheap local task, not a schema column or Phase-A gate.

## 6. Phase-A acceptance contract

Phase A proves one production-shaped `reigh.wan_2_2_t2i` generation and one `rendering.timeline_visualize` render end to end. It does not pass until it demonstrates:

1. truthful local availability gating and useful missing-model, node, or ffmpeg guidance;
2. admission replay plus changed-payload conflict;
3. claim directly into a leased running attempt;
4. heartbeat progress and expiry after worker death;
5. rejection of an expired or superseded fence;
6. multipart completion replay after a lost acknowledgement;
7. rejection of poisoned, truncated, hash-mismatched, and disk-failed output with no partial authority;
8. queued and running cancellation;
9. atomic media, task, generation, and primary-variant publication;
10. concurrent editor save versus internal registry merge without document clobbering;
11. visibility through 2-second active polling;
12. browser playback of managed MP4 via Range/ETag; and
13. successful operation while Supabase and outbound-provider networking are blocked.

Join/travel graph and payload fixtures move to Phase B with their handlers. Old broad migration matrices are historical coverage inventories, not Phase-A release gates.

## 7. Explicit deferrals and configurable defaults

Deferred: remote workers; TLS/auth transport; SSE; queue summary; executor registry; `GET /variants`; thumbnails; document paging; structural orchestration runs; hard delete/media garbage collection; link-in-place media; runtime workflow promotion; multiple executor bindings; and provider fallback.

Attempt quota, request-size limit, lease duration, and expiry cadence are conservative, configurable local code defaults, not frozen wire constants; tune them from measured WGP and render artifacts `[INFERENCE]`. Do not use table-count assertions or dynamic-pack/plugin laws as a Reigh release gate; update concrete schema expectations for pack migration v2.

## Source map

- Primary working contract: source doc 27, all sections.
- Frozen timeline/asset bridge: source doc 09 §§1, 4–7.
- Journey and acceptance framing: source doc 22 §§2–8.
- Binding scope and product decisions: source docs 15, 24, and 25.
- Capability and orchestration simplifications: `grok/second-opinion-decisions.md`.
