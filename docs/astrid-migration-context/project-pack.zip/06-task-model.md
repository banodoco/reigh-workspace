# Task Model: Capabilities, Workflows, Orchestrators, and Executor Builds

This is the end-state task model for local Reigh on Astrid. It incorporates the ratified posture from source doc 26 and `grok/second-opinion-decisions.md`, with source doc 27 controlling implementation details that were simplified later. In particular, kernel ULIDs are now the only task IDs; doc 26's earlier dual-identity/cache proposal is retired.

## 1. The model in one sentence

The frontend admits a product **family**; a small code registry resolves it to one flat capability with one verified local executor; Astrid leases the task to the same-host worker; outputs return through one fenced, atomic completion; custom Comfy workflows use the same path through a generic VibeComfy handler. [Sources: 26 D1–D5; 27 §§3–6]

## 2. Capability identity and registry

### Stable names

- Shipped IDs are `reigh.<normalized_task_type>`, such as `reigh.wan_2_2_t2i`, `reigh.image_upscale`, and `reigh.travel_orchestrator`.
- Semantic categories—media kind, operation, model, or UI grouping—are catalog metadata, never segments added to the capability ID.
- The frontend continues to post `{family, input}`. It does not know executor names or capability strings.
- A legacy spelling may be recorded in `spec_json.source_task_type` for provenance only. It is not an alias.
- Kernel ULIDs are the task IDs used in APIs, dependencies, runs, and idempotency keys. Workers do not pre-generate task UUIDs and there is no alias table. [Sources: 26 D1; `grok/second-opinion-decisions.md` D1; 27 §§3.1, 3.4]

### One registry and one binding

The code-declared registry is the sole capability catalog. Each shipped entry contains only:

```text
capability id
frontend family
input validator / resolver
output policy
one executor binding
availability probe
optional ready_template path + digest
```

The same table drives public admission, form/catalog metadata, exact claim advertisement, and availability. It has no wildcards, database-backed `task_types` authority, backend picker, or post-claim fallback. Switching an implementation requires a reviewed registry change, draining queued/running work as needed, and restarting. [Sources: 26 D1, D3; `grok/second-opinion-decisions.md` D3; 27 §§3.1–3.2]

The binding rule is:

- WGP for the Wan, travel, and join capabilities already implemented around Wan2GP;
- VibeComfy for the remaining image/video generation and edit capabilities;
- Astrid Remotion for `rendering.timeline_visualize`.

The complete shipped public map is:

| Frontend family | Capability or capabilities | Binding |
|---|---|---|
| `image_generation` | `reigh.wan_2_2_t2i`; `reigh.qwen_image`; `reigh.qwen_image_style`; `reigh.qwen_image_2512`; `reigh.z_image_turbo` | WGP for Wan; VibeComfy for the others |
| `image_upscale` | `reigh.image_upscale` | VibeComfy |
| `individual_travel_segment` | `reigh.individual_travel_segment` | WGP |
| `join_clips` | `reigh.join_clips_orchestrator` | WGP |
| `video_enhance` | `reigh.video_enhance` | VibeComfy |
| `z_image_turbo_i2i` | `reigh.z_image_turbo_i2i` | VibeComfy |
| `magic_edit` | `reigh.qwen_image_edit` | VibeComfy |
| `masked_edit` | `reigh.image_inpaint`; `reigh.annotated_image_edit` | VibeComfy |
| `travel_between_images` | `reigh.travel_orchestrator`; `reigh.wan_2_2_i2v` | WGP |
| `crossfade_join` | `reigh.travel_stitch` | WGP |
| `edit_video_orchestrator` | `reigh.edit_video_orchestrator` | WGP |
| `character_animate` | `reigh.animate_character` | VibeComfy |
| `klein_edit` | `reigh.flux_klein_edit` | VibeComfy |
| `render_export` | `rendering.timeline_visualize` | Astrid Remotion |

The executor-only child allowlist is limited to `reigh.join_clips_segment`, `reigh.join_final_stitch`, `reigh.travel_segment`, `reigh.travel_stitch`, and `reigh.join_clips_orchestrator`. The latter two also have public families above, but the internal child form remains protected by the fenced executor gate. Each capability is advertised only when its single binding and prerequisites pass boot preflight. [Source: 27 §3.1]

Dead historical types—including `edit_travel_flux`, `magic_edit`, `single_image`, underscore `image_upscale`, `image_edit`, and `edit_video_segment`—are rejected, not aliased. WGP model/catalog keys and unused specialized handlers remain private implementation details. The old `gpu|api` routing axis, API orchestrator, Fal, and Wavespeed are removed. [Sources: 26 D6 and `run_type`; `grok/second-opinion-decisions.md` D6; 27 §§3.1, 6]

### Availability is admission policy

Worker boot produces a secret-free availability/build manifest that checks the pinned Wan build, model and checkpoint hashes, ComfyUI/VibeComfy nodes, ready-template digests, Remotion/Node/ffmpeg, and disk capacity. The bridge advertises only entries whose one binding passes preflight. A missing prerequisite never triggers cloud fallback: catalog UI provides setup guidance, and direct admission returns `422 capability_unavailable` with `missing_prerequisites` and a `setup_hint`. [Sources: 24 Q3; 26 Grok consequences 4 and `run_type`; 27 §6]

## 3. Ordinary task lifecycle

1. **Admit.** `POST /projects/:slug/tasks` receives a required `Idempotency-Key` and public `{family, input, materialized_inputs?, priority?}`. The resolver validates inputs, resolves project media to stable `media_id`s, selects the single registry entry, and stores an immutable task spec with output-relevant provenance.
2. **Claim.** The local worker advertises its exact available capabilities. Astrid selects eligible work and creates a leased `running` attempt with an attempt number, lease ID, expiry, and fence.
3. **Execute and report.** The bound handler runs locally. Heartbeats extend the lease and carry bounded progress; a small client mutex prevents heartbeat racing terminal complete/fail.
4. **Complete or fail.** Completion uploads raw files and a fenced manifest in one multipart request. The bridge hashes and validates bytes, then atomically commits task/attempt/output/media and optional generation/variant plus required asset-registry visibility. Fail is fenced and the server applies the retry budget.
5. **Observe.** The app polls task state every 2 seconds while active and 10 seconds while idle. Outputs are addressed by media IDs and served from the managed tree, never handed around as storage URLs or local paths.

Admission and completion/failure transport retries reuse their original idempotency keys. Claim and heartbeat are fresh operations rather than receipted commands. [Source: 27 §§4–7]

## 4. Custom Comfy workflow path, end to end

Custom authoring deliberately adds data, not runtime code.

### Authoring contract

A user drops a Comfy workflow plus declarative YAML whose visible schema is only:

```yaml
id: local.my_workflow
ports: {}
workflow_path: workflows/my_workflow.json
digest: sha256:...
output_policy: {}
```

The exact port and output-policy shapes are validated by the shipped schema/scaffolding. Availability probes, origins, resolver IDs, executor binding, and ABI/process requirements are implementation metadata and do not belong in user YAML. No Python module, dynamic plugin, install hook, or database mutation is permitted. [Sources: 26 D5; `grok/second-opinion-decisions.md` D5; 27 §3.3]

### Admission-to-output flow

1. The loader validates the definition and workflow. Admission snapshots the workflow bytes, computes SHA-256 itself, and pins the immutable digest, definition version, typed input ports, output policy, and model hash in the task spec.
2. The public request still uses the product family and project media inputs. The resolver turns those inputs into stable `media_id`s; workflows never receive public storage URLs as authority.
3. The task executes as the single generic `local.workflow.run` capability. A named `local.<slug>` is optional catalog/UX sugar over that mechanism, not a separately extensible handler.
4. The one generic VibeComfy handler claims the exact capability, materializes controlled inputs, loads the digest-pinned snapshot, and reports bounded progress through heartbeat.
5. The handler returns files through the common multipart completion. Astrid hashes them and atomically records managed media, task outputs, and generation/initial variant lineage when the output policy requests it. It may merge asset-registry visibility but never performs document-native shot placement.

This makes replays auditable: the task pins the bytes and versions that can change outputs, while the completion provenance names the process/build manifest that executed them. ComfyUI/node versions, executor protocol, and handler ABI stay in that manifest rather than bloating every task spec. Startup fails closed if bridge and worker registry digests disagree. [Sources: 26 D4–D5 and Grok gap resolutions; `grok/second-opinion-decisions.md` missed items 1 and 6; 27 §§3.2–3.3, 5]

### Shipped workflow promotion

Shipped `reigh.*` Comfy workflows live as reviewed VibeComfy `ready_templates` in the repository. Promotion is a normal code change: copy the vetted snapshot into `ready_templates`, add or update the YAML/code-registry entry and digest, review it, pass availability and execution tests, then restart. V1 has no promotion API, curation database, or second workflow object model. [Sources: 26 D4; `grok/second-opinion-decisions.md` D4]

## 5. Orchestrators: leased parent and fenced children

Travel, join, and edit still need children whose inputs can depend on earlier outputs. V1 keeps executor-created children rather than adding a new kernel yield/resume state machine.

### Parent protocol

1. Public admission creates the parent and run with an immutable, versioned orchestration spec.
2. Claim creates a leased `running` attempt. A `LeaseKeeper` heartbeats bounded progress for as long as the children run; the parent need not hold the GPU execution slot.
3. The executor coordinator reads child/run state. It explicitly completes the parent when all required children succeed, fails it on terminal required-child failure, and propagates cancellation across nonterminal run members.
4. The keeper serializes heartbeat with complete/fail. No `running → blocked → resume` transition is added. [Sources: 26 D2; `grok/second-opinion-decisions.md` D2; 27 §3.5]

### Executor-only child admission gate

Children use the same admission endpoint but require an internal, server-validated envelope containing the running parent ULID, parent attempt number, executor ID, lease ID, and current fence. Admission succeeds only when:

- the parent is still the caller's live, unexpired leased attempt;
- the requested capability is on the child-only allowlist;
- the idempotency key is `reigh.orch:v1:<parent>:<role>:<index>`;
- dependencies are hard edges to kernel task ULIDs; and
- the child inherits the parent's project and run context.

Browser/user origins cannot admit child families even if those capabilities exist. After a crash or lost response, the executor reconstructs its plan from the immutable parent spec and replays the same keys; receipts return the original children rather than duplicating them. Intermediate outputs cross task boundaries only after publication as managed `media_id`s—never via attempt quarantine paths or storage URLs. [Sources: 26 D2 and Grok gap resolutions; `grok/second-opinion-decisions.md` missed items 2–3; 27 §3.5]

The principal correctness risk is the long-lived parent fence: expiry, restart, replay, cancellation, and explicit parent completion need production-shaped tests. Structural runs that pre-materialize a full graph remain a later optimization and must not alter v1 contracts. [Sources: 26 risk section; `grok/second-opinion-decisions.md` D2; 27 §§3.5, 9]

## 6. Wan2GP build and update contract

Wan2GP stays a git submodule, not an unpinned package dependency. The current evidence records:

- repository: `banodoco/Wan2GP`, branch `reigh-sprint-3`;
- reviewed SHA: `181bb71a21008032e4771e11663f33e4489c4512`;
- fixed mount: `reigh-worker/Wan2GP/`;
- in-process boundary: controlled cwd and `sys.path`, mediated by `wgp_bridge.py`;
- patch layer: `wgp_patches.py`;
- model/config layout: `Wan2GP/defaults/`, `finetunes/`, and `ckpts/`;
- boot may rewrite only `Wan2GP/wgp_config.json`.

The update path is: rebase the maintained fork onto the chosen upstream base, review the diff, revalidate path/import and patch contracts, bump the submodule SHA, then run conversion fixtures and representative Wan/travel/join smoke tests. Queue work is drained before the implementation changes, and the prior manifest is retained for rollback. Capability IDs remain stable unless the public input/output contract actually breaks. [Sources: 26 “Wan2GP update contract”; `grok/worker-wgp-report.md` §3]

**[INFERENCE] Executor-build manifest.** Each releasable worker build should record at least `{wan2gp_sha, upstream_base, patchset_hash, worker_contract_version, preset/model/checkpoint_hashes}`. Path/import checks, patch-lifecycle tests, conversion fixtures, and representative capability smokes become release gates; task completion provenance records which manifest ran. This makes upstream drift observable and rollbackable without introducing multi-binding selection into the runtime registry. [Source basis: 26 “Wan2GP update contract”; the manifest addition is explicitly marked inference there]

Known hazards worth keeping in the gates are the in-process cwd/import contract, monkeypatch drift, checkpoint disk pressure, and platform-specific dependencies such as the Darwin-arm64 `decord` wheel gap. Model acquisition must download, verify, and report local availability before the relevant capability is advertised. [Sources: `grok/worker-wgp-report.md` §3; 24 remaining consideration 1]

## 7. What is intentionally deferred

- structural whole-graph runs or a kernel yield/resume state;
- multi-binding selection, A/B executor builds, or post-claim fallback;
- runtime plugins, a workflow promotion service, or a task-types database;
- aliases for legacy task names;
- remote workers and outbound provider routing;
- passing intermediates by path rather than managed media identity.

These are omissions by design: the task model remains extensible through stable capability contracts, immutable workflow snapshots, registry revisions, and provenance without carrying cloud-fleet machinery into a single-user local product. [Sources: 26 ratified decisions; `grok/second-opinion-decisions.md`; 27 §§1, 3, 6, 9]
