# Ten questions for a genius-level engineer

These are not FAQs or reopened owner decisions. They target the remaining mechanisms and thresholds whose answers could most improve correctness, operability, and longevity within the ratified local-first end state. Proposed mechanisms and experiments below are prospective and therefore marked **[INFERENCE]**. (Binding context: source docs 22, 24, 26, and 27.)

## 1. Where exactly is the irreversible point in atomic completion?

How should quarantine-to-managed-media publication, SQLite `BEGIN IMMEDIATE`, content-addressed deduplication, and receipt creation be ordered so that a crash at every instruction boundary yields either a replayable pre-commit state or one fully visible completion—never orphaned authority or a false success?

**Why it matters / unlock:** This is the system's core correctness boundary. A great answer would produce an explicit state machine, crash-point fault-injection matrix, and cleanup ownership rules that prove the database and byte tree cannot disagree. **[INFERENCE]**

## 2. What is the smallest vertical slice that disproves the most architecture?

Beyond the listed Phase-A checks, which single production-shaped t2i-to-gallery-to-timeline-to-Remotion journey, with which forced failures and measurements, would expose a bad bridge contract, wrong authority split, or unusable local setup before broad porting begins?

**Why it matters / unlock:** The vertical slice is valuable only if it attacks the riskiest seams. A great answer would turn Phase A into a falsification experiment with hard evidence, stop/go thresholds, and minimal fixtures—not merely a happy-path demo. **[INFERENCE]**

## 3. What are the measured limits of one CAS-versioned timeline document?

For realistic projects, how do document byte size, parse/serialize cost, save contention, undo history, asset-registry growth, and concurrent internal merges scale—and at which measured thresholds should the product introduce chunking or another document representation without creating a second placement authority?

**Why it matters / unlock:** “One document” is the right semantic model, but its safe operating envelope is not yet quantified. A great answer would define production-shaped generators, percentile budgets, conflict tests, and an evolution seam that preserves one-document semantics. **[INFERENCE]**

## 4. Can capability contracts remain stable while executors evolve independently?

What is the minimal typed boundary among `family` resolution, immutable task spec, capability registry, WGP/VibeComfy/Remotion handlers, output policy, and process manifest that prevents executor quirks from leaking into the public API while still permitting meaningful upgrades?

**Why it matters / unlock:** Too little separation makes every executor update a product migration; too much recreates a plugin platform. A great answer would define the conformance suite and the exact provenance/version fields that distinguish compatible implementation changes from contract breaks. **[INFERENCE]**

## 5. What is the humane, deterministic model-acquisition contract for a fresh machine?

How should setup discover hardware and disk limits, select compatible model/node bundles, download resumably, verify hashes and licenses, report progress, and recover from partial or corrupted installs while advertising only genuinely runnable capabilities?

**Why it matters / unlock:** In a fully local product, installation quality replaces cloud availability as the first-run bottleneck. A great answer would yield a transactional setup state machine, signed/versioned manifests, disk budgets, repair behavior, and actionable `capability_unavailable` guidance. **[INFERENCE]**

## 6. How can Wan2GP upgrades be made boring and reversible?

What automated compatibility and output checks should guard the submodule rebase, patchset, fixed-path/import assumptions, configs, checkpoints, and worker protocol—and what constitutes an automatic rejection versus a safe manifest bump?

**Why it matters / unlock:** Wan2GP is powerful but carries the highest upstream-drift risk. A great answer would define a hermetic build, representative capability corpus, semantic diff policy, drain/rollback procedure, and provenance that can reproduce any accepted output environment. **[INFERENCE]**

## 7. What invariant makes orchestrator crash-replay provably duplicate-free?

Across parent lease expiry, fence changes, lost child-admission acknowledgments, deterministic replays, partially completed fan-out, cancellation, and executor restart, what durable facts let a new coordinator reconstruct exactly what must happen next without duplicate children or double parent completion?

**Why it matters / unlock:** Long-lived leased parents are the largest cutover risk identified in the task-model review. A great answer would provide a formal transition model, deterministic child identity scheme, recovery algorithm, and exhaustive interleaving tests. **[INFERENCE]**

## 8. What is the correct local-trust boundary—not merely the convenient one?

Given loopback HTTP, browser origins, executor-only child admission, local workflow snapshots, media paths, and potentially hostile project inputs, what threats remain from other local processes, malicious web pages, workflows, archives, or filenames, and which low-cost controls close them without rebuilding cloud auth?

**Why it matters / unlock:** “Single user” removes tenancy but not confused-deputy, cross-origin, parser, and local-process risks. A great answer would produce a concrete threat model and a minimal defense set covering origin binding, request capabilities, path confinement, resource limits, workflow validation, and secret handling. **[INFERENCE]**

## 9. What performance envelope should the product explicitly promise?

For supported hardware tiers, what budgets should govern cold start, claim latency, progress freshness, SQLite writer occupancy, editor save time, gallery paging, thumbnail generation, render playback startup, disk growth, and recovery—and which workloads should be refused or degraded gracefully?

**Why it matters / unlock:** Local-first quality depends on predictable resource behavior more than theoretical throughput. A great answer would establish tiered service-level targets, a reproducible benchmark corpus, backpressure rules, and telemetry that stays local and actionable. **[INFERENCE]**

## 10. Which seams preserve future options without prebuilding them?

If a future version needs larger documents, another local executor, remote execution, multi-user collaboration, or synchronization, which small choices now—stable media identity, immutable specs, event boundaries, capability conformance, export formats, or backup semantics—keep those paths open without weakening the v1 constraints?

**Why it matters / unlock:** Premature extensibility would recreate the complexity being removed, while accidental lock-in could make success expensive to extend. A great answer would identify a short list of low-cost, testable “option-preserving” invariants and explicitly reject every speculative abstraction that does not protect one. **[INFERENCE]**
