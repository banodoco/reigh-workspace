# Reigh on Astrid: project overview

## The project in one sentence

Reigh is being rebuilt from a cloud-shaped, Supabase/Postgres-backed generative-video product into a fresh-start, single-user desktop-local product: one browser editor, one loopback HTTP bridge, one Astrid SQLite authority, one managed media tree, and one same-host worker running Wan2GP, VibeComfy, and Astrid/Remotion tasks. This is a product rebuild, not a database migration or a “local mode” bolted onto the hosted system. (Sources: docs 22 §§2–3; 25 statements 1, 5, 7–9; 27 §§1, 6.)

## What Reigh is today

The existing Reigh is a browser-based creative application for generating media, collecting generations and variants, arranging shots, editing a video timeline, and rendering results. Its current execution system is cloud-shaped. The Next.js frontend sends a family-shaped request to a Supabase edge function; Postgres holds queued tasks; GPU workers and an API orchestrator poll and claim them; a separate capacity orchestrator can start and stop RunPod workers; outputs go through Supabase Storage; completion creates generation records and triggers credit accounting; and Supabase Realtime publishes changes back to clients. Auth, row-level security, billing, sharing, worker routing, provider integrations, and a substantial relational data model all belong to that hosted architecture. (Sources: docs 02 §1; 03; 06; 14 §§1–4.)

Reigh already has the beginning of a different path. Astrid exposes a real, CI-tested loopback bridge for project and timeline discovery, whole-document timeline load/save, optimistic compare-and-swap (CAS), and verified media delivery with Range and ETag support. Timeline writes pass through Astrid's SDK and one writer queue into SQLite; the browser does not open the database. That bridge is deliberately narrow and domain-shaped rather than a generic table API. The rebuild keeps that foundation and extends the same listener with the task, generation, and media operations the complete local product needs. (Sources: docs 09 §§1–6; 27 §§1, 4.)

## Why rebuild on Astrid

The objective is not merely to replace Postgres syntax with SQLite syntax. It is to remove the distributed-system obligations that do not serve a trusted, single-user tool. A local Reigh does not need cloud tenancy, JWTs, RLS, personal access tokens, credits, Stripe, public sharing, remote fleet control, outbound providers, or several components competing to decide what is true. Re-creating those systems locally would retain their complexity while discarding the reason they existed. The ratified choice is therefore one authority and a smaller product boundary. (Sources: docs 15 Q3/Q5 and “Binding decisions”; 22 §§1–3; 25 statements 1, 5, 7, 8; 27 §1.)

Astrid supplies the load-bearing local primitives: a SQLite kernel with tasks, attempts, dependencies, outputs, receipts, events, runs, timelines, and media metadata; a single serialized writer path; leased and fenced execution attempts; content-addressed managed media; and the existing HTTP bridge. Those primitives let Reigh preserve the behavior that matters—durable task admission, crash recovery, idempotent commands, atomic completion, timeline conflict detection, provenance, and playable outputs—without preserving the hosted control plane. Workers remain ordinary HTTP clients and never acquire a second database path. (Sources: docs 04; 09 §§2–6; 22 §§2–4; 27 §§2, 4–6.)

The product model also becomes clearer. Generations and their variants are relational records because the gallery and provenance need stable identities and bounded queries. Shot groups, pools, timing, ordering, clip placement, and boundary overrides belong only to the timeline document because they are editing structure. The focused shot editor is consequently a view mode over the same document, save path, CAS version, and undo history as the video editor—not a second editor with a synchronization problem. (Sources: docs 24 Q1; 25 statements 2–4 and 10; 27 §§1–2, 7.)

## How the design converged

The corpus records a deliberate narrowing rather than a single speculative leap:

1. **Forensics established the current systems.** Repository and live-schema inventories traced Reigh's Postgres schema, task pipeline, worker execution, frontend data usage, edge functions, and deployed drift. Parallel work documented Astrid's SQLite kernel, package semantics, and frozen bridge. These documents remain evidence, not current implementation authority. (Sources: dossier README; docs 01–12.)
2. **The first integration design identified the right seam.** It proposed `astrid serve` as the sole persistence boundary, family-based task admission over HTTP, fenced Astrid attempts, managed media, domain routes, and polling. At that stage, the design still included an operator migration and rollback period. (Source: doc 14 §§1–4.)
3. **Owner decisions removed the cloud-shaped surface.** The first ratification selected same-host workers, no new auth, and removal of billing, public sharing, tenancy, and fleet scaling. The second ratification went further: placement became document-native; all compute became local; render moved to Astrid/Remotion; media became copy-only; and roughly two-second polling was accepted. Most importantly, “fresh start” became literal—old Supabase data is not a later product migration. (Sources: docs 15; 24 Q1–Q6; 25.)
4. **Independent simplicity review cut speculative machinery.** The accepted decisions retained flat capability names, exactly one installed binding per capability, immutable custom-workflow snapshots, in-repository ready templates, trimmed declarative definitions, rejection of dead legacy types, executor-only child admission, and leased orchestrator parents. They rejected runtime plugins, alias tables, binding selectors, a promotion service, and premature graph orchestration. (Sources: `grok/second-opinion-decisions.md`; doc 22 §1.)
5. **One spec and one journey replaced competing drafts.** Doc 27 is now the sole working build contract; doc 22 is the three-phase delivery plan. Earlier route, schema, worker, and task-model proposals are useful evidence only where the constitution and doc 27 preserve them. (Source: dossier README “Current authority and reading order.”)

This authority order matters: the ratified constitution (docs 15, 24, 25, and the Grok second-opinion decisions) controls product intent; doc 27 controls the build; doc 22 controls sequence. Historical designs cannot silently restore a cut feature.

## The destination

In the finished product, the Reigh browser talks only to `astrid serve` on loopback. The bridge admits frontend requests by the familiar `family` key and resolves each to one flat capability such as `reigh.wan_2_2_t2i`; each capability has exactly one local executor binding. A single supervised worker claims directly into leased running attempts and dispatches internally to Wan2GP, VibeComfy, or Astrid/Remotion. It heartbeats while working and completes through one multipart call. The server prepares and hashes the returned bytes, then atomically commits the attempt, task, outputs, media records, optional generation and primary variant, and any required timeline asset-registry visibility. Either the complete authoritative result appears, or none of it does. (Sources: docs 22 §2; 27 §§3–6.)

The browser sees progress by polling: every two seconds while work is active, every ten seconds when idle, plus a 30-second timeline safety refresh. Correctness does not depend on push delivery; it comes from command receipts, idempotency, live lease fences, the single writer, and timeline CAS. A render is submitted through the same task route, executed locally through Astrid's Remotion capability, committed as managed MP4 media, and played through the bridge. (Sources: docs 24 Q4/Q6; 25 statements 6 and 9; 27 §§4, 5, 7.)

The machine is the data center. If a required model, workflow, node, Node/ffmpeg component, or disk budget is unavailable, the capability is not advertised and direct use returns actionable setup guidance; there is no silent cloud fallback. Imported files and outputs are copied into Astrid's SHA-256 managed tree. The SQLite file owns structured truth; the media tree owns bytes. Backup and restore protect that local authority. (Sources: docs 24 Q3/Q5 and remaining consideration 1; 22 §§5–6; 27 §§2, 6.)

What will not survive is as important as what will: no login, accounts, RLS, PATs, credits, billing, public sharing, cloud generation, remote workers, autoscaling, Supabase runtime, provider secrets, legacy aliases, runtime plugins, second placement store, product importer, historical replay layer, or rollback authority. There is also no cloud/cross-device synchronization service; “realtime” means local polling against the same bridge. Video export still exists, but it is a local render task—not a legacy-data exporter or browser download trick. (Sources: docs 22 §§3, 7; 25; 27 §§1, 4.1, 6–7.)

## The build journey

Delivery is intentionally staged around proof rather than breadth:

- **Phase A proves the architecture vertically.** One real `wan_2_2_t2i` request must travel from browser admission through local execution and atomic completion into managed media and the generation gallery; one timeline render must become a browser-playable managed MP4. Missing prerequisites, idempotent replay, changed-payload conflict, lease loss, crash/reclaim, stale fences, truncated output, disk failure, cancellation, and concurrent editor-save/registry-merge all have explicit acceptance tests. Supabase and outbound-provider networking are blocked during acceptance. (Source: doc 22 §4; doc 27 §8.)
- **Phase B broadens only the proven seam.** Remaining local capabilities are enabled when their single binding passes availability checks. Join, travel, and edit orchestrators stay leased while their fenced executor admits deterministic, allowlisted children with hard dependencies and crash-safe replay. Custom Comfy tasks use trimmed YAML plus immutable workflow snapshots and one generic VibeComfy handler. (Sources: doc 22 §5; `grok/second-opinion-decisions.md` D2–D5; doc 27 §3.)
- **Phase C cuts the application over.** All retained PostgREST, RPC, storage, realtime, and edge-function paths are replaced by bridge domain clients. The document-native shot view, copy-only media, local setup/doctor, launcher supervision, backup/restore, render playback, and clean-install experience ship together; hosted-era code paths are removed. Release requires a complete empty-authority journey with no Supabase or provider credential, endpoint, export, or second structured store. (Source: doc 22 §6.)

## Principles that decide hard cases

- **One authority:** Astrid SQLite is the sole structured source of truth; the managed SHA-256 tree is authoritative for bytes.
- **One bridge:** browser and worker use the loopback HTTP listener; all mutations reach the one writer queue; no worker opens SQLite.
- **One document:** the timeline owns editing structure, including shot placement; the shot editor is a focused mode over it.
- **Local first, literally:** generation, orchestration, and render run on the user's machine, with truthful availability gating.
- **Fresh start:** preserve lessons and contracts, not hosted data, compatibility aliases, migration machinery, or rollback authority.
- **Atomic truth over clever transport:** polling may delay visibility, but receipts, fences, CAS, and one completion transaction determine correctness.
- **Boring seams, measured scale:** bounded relational gallery reads coexist with document-native placement; paging, thumbnails, new routes, or richer transports are added only after evidence. (Sources: docs 22 §§2–8; 25; 27.)

