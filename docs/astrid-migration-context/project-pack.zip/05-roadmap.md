# Reigh on Astrid: three-phase delivery roadmap

This roadmap takes Reigh from its current Supabase/Postgres and GPU-worker architecture to a fresh-start, fully local, bridge-only product. It is deliberately ordered around proof: first establish the smallest complete path and its failure semantics; then widen capability coverage; only then cut the application over and release it. Source document 22 is the current journey plan, source document 27 is the working build contract, and ratified source documents 15, 24, 25, plus `grok/second-opinion-decisions.md`, set the constitutional boundary.

## Destination and rules of travel

The destination is a Reigh browser/editor speaking HTTP to loopback `astrid serve`, backed by one Astrid SQLite authority and one SHA-256 managed media tree. One supervised same-host worker runs WGP, VibeComfy, and Astrid Remotion handlers. The browser admits tasks by frontend family; the bridge resolves one flat capability ID to one installed local binding. Workers claim leased attempts, heartbeat, and settle all output state through one atomic completion transaction.

The timeline document is the only placement model. The shot editor becomes a focused mode of the video editor, with the same document, save path, and undo history. Generations and variants remain relational. Render is an ordinary task producing a managed MP4. Polling provides freshness at 2 seconds active, 10 seconds idle, and 30 seconds for timeline safety; receipts, fences, and timeline CAS provide correctness.

The journey is a fresh start. It does not include a production exporter, importer, replay layer, operator dump, archive, rollback window, or historical-data compatibility work. It also does not preserve Supabase or cloud providers as fallback authorities.

## Phase A — prove the vertical slice: local text-to-image plus render

### Goal

Prove the entire local architecture, including failure recovery, with the smallest production-shaped user journey before porting broad capability or UI surface.

### Build

1. Write a code-based note of the existing completion side effects; do not inspect or dump live production as journey work.
2. Establish a local availability matrix for the pinned Wan build, model hashes, ComfyUI/VibeComfy nodes, ready-template digests, Node/ffmpeg/Remotion, and disk capacity.
3. Add only `generations` and `generation_variants` to the pack, with one-primary, unique media membership, media pinning, lineage, valid JSON, soft deletion, and required indexes. Implement generation projection inside atomic task completion; do not add generation event streams or relational placement.
4. Implement the minimal surviving HTTP surface: project-scoped task admission/read/cancel, claim directly to leased `running`, heartbeat, multipart complete, fail, common media reads, bounded generation reads, and the already-frozen timeline CAS and asset routes. Add the internal lease-expiry loop.
5. Run one worker process beside `astrid serve`; remove Phase-A dependencies on Supabase, provider APIs, the old API orchestrator, queue summary, and executor registry.
6. Carry one real `wan_2_2_t2i` request from editor admission through WGP, managed media, atomic settlement, and a gallery generation/primary-variant row.
7. Admit `render_export` through the common task route, resolve it to `rendering.timeline_visualize`, execute it locally, observe it through common task reads, and play its managed MP4 in the browser.
8. Wire 2-second active polling, 10-second idle polling, the existing 30-second timeline safety refresh, and immediate invalidation on admission, cancellation, and observed completion.

### Exit criteria

Phase A passes only when all of the following are exercised on production-shaped fixtures:

- local success and actionable missing-model, missing-node, and missing-ffmpeg setup responses;
- admission receipt replay and changed-payload conflict;
- direct leased-running claim, progress heartbeat, worker-death expiry, reclaim, and stale/superseded fence rejection;
- multipart completion replay after a lost acknowledgement;
- poisoned, truncated, hash-mismatched, over-limit, and disk-failed outputs yielding no partial authoritative state;
- queued and running cancellation;
- exactly atomic task, attempt, media, output, generation, and primary-variant publication;
- concurrent editor save versus internal asset-registry merge without clobbering the document;
- active progress visibility within the 2-second polling promise;
- browser MP4 Range/ETag playback; and
- successful operation while Supabase and outbound-provider networking are blocked.

Join/travel graphs and payload fixtures are intentionally not Phase-A gates. The old broad A–N/T1–T12 matrices remain historical coverage inventories rather than day-one release criteria.

## Phase B — remaining local capabilities and orchestrator children

### Goal

Expand the product only after the lease, fence, replay, media, and completion boundaries have proved trustworthy.

### Build

- Enable each retained capability only when its single WGP or VibeComfy binding and prerequisites pass the boot availability probe. Never select among bindings or fall back to a cloud provider.
- Port the remaining family resolvers and payload builders behind the bridge. Keep `family` as the UI/admission key, flat capability IDs in the registry, and kernel ULIDs for tasks and dependencies. Add no task-types table, wildcard admission, alias layer, or logical-ID cache.
- Implement join/travel/edit orchestrators as long-lived leased parents. Only their live fenced executor may admit allowlisted child types, using deterministic `reigh.orch:v1:<parent>:<role>:<index>` keys, inherited project/run context, and hard dependencies.
- Make parent heartbeats, crash replay of receipted child admission, dependency observation, and explicit parent complete/fail first-class behavior. Parent attempts do not occupy GPU capacity while waiting.
- Drop unread legacy route-control contract blocks `[INFERENCE]`; retain `orchestrator_details` and other payload fields only where handlers demonstrably read them.
- Add production-shaped join/travel fixtures alongside the handlers they validate.
- Add the trimmed declarative custom-workflow path: YAML `{id, ports, workflow_path, digest, output_policy}`, immutable admission snapshot, digest pinning, in-repository `ready_templates`, and one generic VibeComfy handler. Do not add runtime code plugins or a promotion service.

### Exit criteria

Every advertised capability executes entirely locally through exactly one truthful binding. Missing prerequisites hide or disable the capability with useful setup guidance. Browser callers cannot admit child-only families. Crash or lost acknowledgement cannot duplicate children. Parent leases recover, hard dependencies enforce ordering, and the fenced executor alone can settle the parent. No retained handler uses Supabase, Fal, Wavespeed, RunPod, or another outbound provider.

## Phase C — application cutover and local release

### Goal

Make the supported product bridge-only, expose the complete local operating experience, and retire the legacy runtime paths.

### Build

- Replace retained PostgREST, RPC, Supabase Storage, realtime, and edge-function calls with typed bridge domain clients.
- Ship document-native shot mode as a focused view over the one timeline document, one CAS save path, and one undo history. Do not mirror placement into `shots`, `shot_items`, or another store.
- Ship always-copy media import and output handling, local model/node setup and doctor UX, launcher supervision, backup/restore, bounded gallery reads, and managed render playback.
- Measure representative timeline JSON size, gallery delivery, disk usage, and deep-copy behavior. Add paging, thumbnail work, or another projection only after evidence justifies it.
- Remove account, auth, tenancy, billing/credits, referrals, public sharing, training, agent-session, provider, cloud-fleet, Supabase, importer, rollback, and legacy editor-authority code paths.
- Run clean-install and upgrade acceptance with Supabase and outbound-provider networking blocked.

### Exit criteria

The browser communicates only with `astrid serve`. From an empty local authority, supported generation, orchestration, document editing, shot-focused editing, cancellation, gallery, media, render, backup, and restore journeys all work. Startup and supported workflows require no Supabase/provider credential or endpoint, no data export, no rollback window, and no second structured store. The released build has one database, one managed media tree, one bridge, one writer queue, and one document-native placement authority.

## Deferred and explicitly out of scope

The following do not block any v1 phase:

- remote or RunPod workers and the authenticated/TLS transport they would require;
- SSE, WebSockets, or a browser event stream;
- multiple executor bindings, admission-time binding selection, or provider fallback;
- runtime plugin loading or workflow-promotion services;
- legacy capability aliases and unknown-family passthrough;
- structural whole-graph orchestration;
- queue-summary and executor-registry/heartbeat surfaces;
- project-wide `GET /variants`;
- thumbnail tasks and columns;
- document paging or premature placement normalization;
- link-in-place media;
- hard deletion and media garbage collection;
- auth, accounts, tenancy, billing, sharing, cloud providers, and cloud fleet controls; and
- production import/export/replay/archive/rollback authority.

References, evidence, understanding, existing kernel hash-chained events, kernel ULIDs, backup/restore, and frozen timeline bridge routes are not migration targets and remain untouched.

## Cross-phase risks and gates

| Risk | Gate that controls it |
|---|---|
| Partial completion leaks task/media/gallery disagreement | One prepared-byte phase, one `BEGIN IMMEDIATE`, receipt replay, and Phase-A fault injection before Phase B. |
| Worker registry merge overwrites a concurrent edit | Evented registry-only merge against current head; workers never issue a public full-document save. |
| Heartbeat races terminal settlement | One worker-side mutex, stop-heartbeat-before-terminal rule, expiry, and fence tests. |
| Orchestrator recovery duplicates or misorders children | Deterministic child keys, live parent fence gate, kernel ULIDs, hard dependencies, and replay fixtures in Phase B. |
| A fresh machine lacks weights, nodes, render tools, or disk | Boot manifest, verified acquisition/setup, disk preflight, truthful advertisement, and actionable errors. |
| Wan or Comfy workflow drift changes outputs | Pin workflow digest/model hash on tasks; record process build and node facts in the boot manifest. |
| Timeline or gallery grows beyond comfortable local delivery | Measure production-shaped projects; introduce projection or paging only when limits are observed. |
| Simplified public errors impede debugging | Five stable new-route categories plus detailed structured local logs; preserve frozen timeline/CAS errors. |

## Immediate starting sequence

1. Land the local availability matrix and code-based completion-effects note.
2. Implement the two-table pack migration and atomic completion unit of work.
3. Prove the Phase-A `wan_2_2_t2i` and render slice through the minimal protocol before widening scope.

## Source map

- Primary journey plan: source doc 22 §§2–9.
- Binding implementation and Phase-A contract: source doc 27 §§1–10.
- Frozen bridge and timeline CAS: source doc 09 §§1, 4–7.
- Document-native placement, fully local execution, render, copy-only media, and polling: source docs 23–25.
- Capability, binding, custom-workflow, and orchestrator posture: source doc 26 plus `grok/second-opinion-decisions.md`, as consolidated by doc 27.
