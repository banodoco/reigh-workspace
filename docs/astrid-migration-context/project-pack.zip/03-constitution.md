# Reigh-on-Astrid Constitution

**Status:** binding product decisions, ratified 2026-08-21. This document consolidates the current decisions in source docs 15, 24, and 25 and the adopted task-model review in `grok/second-opinion-decisions.md`. The current build contract is source doc 27. Where an older migration design conflicts with the later fresh-start decision, the fresh-start decision controls.

## The product boundary

Reigh is a fresh-start, local, single-user creative editor. One Astrid SQLite file is the only authority for structured state, and Astrid's SHA-256 managed-media tree is authoritative for bytes. The browser and one same-host worker communicate through the loopback Astrid HTTP bridge; workers never open SQLite and every mutation passes through Astrid's single writer. Supabase, a worker-owned database, a placement database, and the filesystem cannot become competing sources of structured truth. [Sources: 15 Q3 and binding decisions; 25 #1, #5, #7; 27 §§1–2]

The supported product does **not** contain:

- login, accounts, JWTs, RLS, personal access tokens, multi-user tenancy, sharing, referrals, credits, Stripe, or billing;
- remote or RunPod workers, cloud autoscaling, Fal, Wavespeed, or any other outbound generation provider;
- training-data management or timeline-agent session history;
- a production-data importer, exporter/replay layer, historical-compatibility path, or rollback authority;
- a second shot editor, a relational shot-placement mirror, runtime code plugins, or a dynamic task-type authority.

Provider credentials must never be stored in SQLite. In the v1 product there are no generation-provider credentials at all; local setup secrets that may exist for unrelated integrations belong in the environment or OS keychain. Loopback binding, strict CORS, and request validation replace cloud authentication for this release. [Sources: 15 Q5 and binding decisions; 24 Q3; 25 #1, #7, #8; 27 §1]

### Fresh start supersedes migration work

Doc 15 originally ratified selective legacy import, JSONL audit exports, cold archival before Supabase destruction, and a read-only rollback period. The later fresh-start constitution removes those activities from the supported product and from the build journey: old Supabase data is intentionally absent, not waiting for a future importer. Legacy schemas and migration reports remain forensic evidence only. This does not authorize careless destruction of an existing deployment; it means preservation or disposal, if ever undertaken, is a separate operator decision and not a Reigh v1 feature. [Sources: 15 Q1–Q6; 24 status and remaining consideration 7; 25 #8; corpus README; `grok/simplicity-review.md` §1]

## One document, one editor

The shot editor is a focused **view mode** of the video editor. It uses the same timeline document, save path, CAS version, and undo history. Shot groups, generation pools, timing, ordering, clip boundaries, and boundary overrides live directly in `timelines.document_json` and its `asset_registry_json`, stored as CAS-versioned JSON in the same SQLite database. “Document-native” does not mean another document store. [Sources: 24 Q1; 25 #2–#4]

Generations and their variants remain relational rows so the gallery, provenance, primary-variant, and lineage queries have stable identities. Placement is document structure. There are no `shot_generation_items` or equivalent placement rows to reorder, mirror, or reconcile; Astrid's older `shots`/`shot_items` pack is not Reigh authority. Worker completion may merge required asset-registry visibility against the current document head, but it must never overwrite shot structure or perform a public whole-document save. [Sources: 24 Q1; 25 #3–#4 and #10; 27 §§2.2–2.3, 5, 7]

A group duplicate is a **deep copy**. It copies the group structure and media references and enqueues or copies the generated final-video assets so the duplicate is independent. The duplicate records source lineage such as `derived_from` or `based_on`. This is a document command, not a set of placement-row mutations; disk usage is part of the product cost, with content-addressed deduplication helping only when bytes are identical. [Source: 24 Q2]

Document and gallery scale are measured before new authority is invented. A thousand-item gallery is solved with bounded generation reads and, later, local thumbnail tasks. Timeline JSON size is measured with production-shaped fixtures; paging or laziness is introduced only from evidence, never by rebuilding placement tables. [Sources: 24 remaining considerations 2–3; 25 #10; 27 §7]

## Local compute, media, render, and freshness

The user's machine is the data center. All generation and render work runs locally through Wan2GP, VibeComfy, or Astrid Remotion. There is no silent cloud fallback. A capability is advertised only when its one local executor and required models, nodes, binaries, templates, hashes, and disk checks pass startup preflight; otherwise it is hidden or disabled with a useful setup prompt, and direct admission returns `422 capability_unavailable`. Model acquisition, verification, update, and disk-space preflight are therefore product-critical setup work. [Sources: 24 Q3 and remaining consideration 1; 25 #7; 26 D3 and `run_type`; 27 §§3, 6]

Imported and generated media is always copied into Astrid's managed SHA-256 tree. V1 has no link-in-place mode and therefore no supported broken-link state. Structured facts about media live in SQLite; the tree stores bytes. [Sources: 24 Q5; 25 #5; 27 §§1, 5]

Export is an ordinary task. The app admits `render_export`, which resolves to Astrid's native `rendering.timeline_visualize`; Astrid runs Remotion locally, commits the MP4 as managed media through the same atomic completion path, and the browser plays it through the bridge with Range/ETag support. Browser Remotion preview may remain a secondary preview, but it is not the authoritative export pipeline. [Sources: 24 Q4; 25 #9; 27 §§3.1, 4.1, 5]

Polling is the realtime contract: approximately 2 seconds while work is queued or running, 10 seconds while idle, and 30 seconds for timeline safety refresh. Admission, cancellation, and observed terminal transitions invalidate relevant reads immediately. SSE and WebSockets are deferred; correctness comes from idempotency receipts, attempt leases/fences, and timeline CAS, while polling controls only visibility latency. [Sources: 15 Q7; 24 Q6; 25 #6; 27 §7]

## Task and capability law

Shipped capabilities have flat, stable IDs of the form `reigh.<normalized_task_type>`; the sole spelling normalization is exemplified by legacy `image-upscale` becoming `reigh.image_upscale`. Semantic taxonomy is catalog metadata, not identity. The frontend submits `{family, input}` rather than capability strings; the adapter resolves the family. A ported source string may survive only as provenance in `spec_json.source_task_type`. Kernel ULIDs are task identities everywhere—there is no worker UUID alias or `logical_task_id` table. [Sources: 26 D1; `grok/second-opinion-decisions.md` D1; 27 §§3.1, 3.4]

One code-declared registry drives admission, validation, catalog metadata, availability, claim advertisement, output policy, and executor binding. There are no wildcards and no database `task_types` authority. Every capability has exactly one local binding in the running registry: Wan/travel/join work already resident in Wan2GP uses WGP; remaining generation work uses VibeComfy; render uses Astrid Remotion. Changing a binding is a reviewed registry edit followed by drain/restart, not a per-task selector, and there is no post-claim fallback. The old `gpu|api` scheduling axis and provider handlers are deleted. [Sources: 26 D1, D3, and `run_type`; `grok/second-opinion-decisions.md` D3; 27 §§1, 3, 6]

Dead historical types are rejected outright, never aliased and never placed on a child allowlist. This includes `edit_travel_flux`, `magic_edit`, `single_image`, underscore `image_upscale`, `image_edit`, `edit_video_segment`, and inactive types such as `banodoco_timeline_generate`. WGP catalog names and obsolete specialized handler names remain private implementation details. [Sources: 26 D6; `grok/second-opinion-decisions.md` D6; 27 §3.1]

## Workflows and extension boundary

Shipped Comfy workflows are reviewed, in-repository VibeComfy `ready_templates` referenced by the code registry. User workflows are immutable snapshots: admission hashes the workflow bytes and pins the digest. The only custom execution mechanism is generic `local.workflow.run`; a named `local.<slug>` entry is optional catalog/UX sugar, not a new runtime object model. Promoting a workflow is a git-reviewed copy into `ready_templates`, registry/YAML update, and restart—not a promotion service or curation database. [Sources: 26 D4–D5; `grok/second-opinion-decisions.md` D4–D5; 27 §3.3]

The user-facing declarative definition is deliberately small: `{id, ports, workflow_path, digest, output_policy}`. Availability probes, origin rules, resolvers, executor binding, and ABI/process requirements belong to shipped registry entries or the process manifest, not user YAML. Every custom definition goes through one generic VibeComfy handler. V1 permits no runtime Python/plugin loading and templates cannot mutate the database directly. A task pins only output-determinative provenance—definition version, workflow digest, and model hash—while executor, ComfyUI/node, and ABI versions belong in the boot/build manifest and completion provenance. Registry-digest disagreement fails closed at startup. [Sources: 26 D5 and risk section; `grok/second-opinion-decisions.md` D5 and missed items 6–7; 27 §§3.2–3.3]

## Orchestrator law

Travel, join, and edit orchestrators retain worker-created children in v1, but the kernel—not the browser or the worker filesystem—controls admission and dependency state:

1. The parent is a kernel task with an immutable orchestration spec. On claim it becomes `running` under a live leased attempt and stays leased while children execute, without occupying the GPU slot.
2. The owning executor heartbeats bounded progress and serializes heartbeat against terminal complete/fail. There is no new yield, blocked-parent, or resume transition.
3. Only that executor may admit a child, using a server-validated envelope containing the live parent ULID, attempt, executor, lease, and fence. The child capability must be on the internal allowlist; browser/user admission is forbidden.
4. Child admission uses deterministic idempotency key `reigh.orch:v1:<parent>:<role>:<index>`, inherits project/run context, and creates hard dependencies using kernel ULIDs.
5. After a lost acknowledgement or crash, the executor replays the same receipted child admissions rather than creating duplicates. After all required children succeed it explicitly completes the parent; terminal child failure fails the parent, and cancellation covers nonterminal run members.

The long-lived parent lease, fenced child gate, receipt replay, crash recovery, and explicit terminal transition are cutover requirements. Structural whole-graph runs are deferred and must not leak into v1 contracts. [Sources: 26 D2 and gap resolutions; `grok/second-opinion-decisions.md` D2 and missed items 2–3; 27 §§3.4–3.5]

## Non-negotiable correctness principles

- One authority: all structured mutations go through the Astrid writer into one SQLite database.
- One bridge: browser and worker use the same loopback HTTP boundary; the worker has no direct-database fallback.
- One document: editor and shot mode share one CAS-versioned timeline and undo history.
- One binding: each advertised capability resolves to one locally verified executor.
- Atomic visibility: a successful completion publishes task/attempt/output/media and, when requested, generation/variant plus registry visibility together, or publishes none of them.
- Fresh means fresh: the supported release operates with Supabase and outbound-provider networking blocked.

[Sources: 24–25; `grok/second-opinion-decisions.md`; 27 §§1, 5, 8–9]
